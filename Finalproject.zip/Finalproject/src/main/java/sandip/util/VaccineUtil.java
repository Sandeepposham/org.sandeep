package sandip.util;

import org.springframework.stereotype.Component;

import sandip.model.Vaccine;

@Component
public class VaccineUtil {

	public void mapToActualObject(Vaccine actual, Vaccine vaccine) {
		if(vaccine.getName()!=null)
			actual.setName(vaccine.getName());
		
		actual.setHospitalname(vaccine.getHospitalname());
		actual.setPhnumber(vaccine.getPhnumber());
		if(vaccine.getEmail()!=null)
			actual.setEmail(vaccine.getEmail());
		actual.setAddress(vaccine.getAddress());
	}

}
