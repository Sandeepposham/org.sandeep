package sandip.util;

import org.springframework.stereotype.Component;

import sandip.model.Bookbed;

@Component
public class BookbedUtil {

	public void mapToActualObject(Bookbed actual, Bookbed ambulance) {
		if(ambulance.getName()!=null)
			actual.setName(ambulance.getName());
		
		actual.setNumbertestdose(ambulance.getNumbertestdose());
		actual.setPhnumber(ambulance.getPhnumber());
		actual.setCovidreport(ambulance.getCovidreport());
		actual.setOxyfacility(ambulance.getOxyfacility());
		if(ambulance.getEmail()!=null)
			actual.setEmail(ambulance.getEmail());
		actual.setAddress(ambulance.getAddress());
	}

}
