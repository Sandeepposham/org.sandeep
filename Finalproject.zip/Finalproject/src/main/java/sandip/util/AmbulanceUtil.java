package sandip.util;

import org.springframework.stereotype.Component;

import sandip.model.Ambulance;

@Component
public class AmbulanceUtil {

	public void mapToActualObject(Ambulance actual, Ambulance ambulance) {
		if(ambulance.getName()!=null)
			actual.setName(ambulance.getName());
		
		actual.setHospitalname(ambulance.getHospitalname());
		actual.setPhnumber(ambulance.getPhnumber());
		if(ambulance.getEmail()!=null)
			actual.setEmail(ambulance.getEmail());
		actual.setAddress(ambulance.getAddress());
	}

}
