package sandip.model;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.Data;
@Entity
@Table
public class Bookbed {
	@Id
	@GeneratedValue

	private Integer id;
	
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	
	public Double getPhnumber() {
		return phnumber;
	}
	public void setPhnumber(Double phnumber) {
		this.phnumber = phnumber;
	}
    
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	


	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}


	public String getNumbertestdose() {
		return numbertestdose;
	}
	public void setNumbertestdose(String numbertestdose) {
		this.numbertestdose = numbertestdose;
	}
	public String getCovidreport() {
		return covidreport;
	}
	public void setCovidreport(String covidreport) {
		this.covidreport = covidreport;
	}
	public String getOxyfacility() {
		return oxyfacility;
	}
	public void setOxyfacility(String oxyfacility) {
		this.oxyfacility = oxyfacility;
	}


	@Column
	private String name;
	@Column
	private Double phnumber;
	private String numbertestdose;
	private String address;
	private String covidreport;
	private String oxyfacility;
	private String email;
	
}
