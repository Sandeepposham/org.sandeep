package sandip.service;

import java.util.List;
import java.util.Optional;

import sandip.model.Vaccine;

public interface IStudentService5 {

	Integer saveStudent(Vaccine s);
	void updateStudent(Vaccine s);
	
	void deleteStudent(Integer id);

	Optional<Vaccine> getOneStudent(Integer id);
	List<Vaccine> getAllStudents();

	boolean isStudentExist(Integer id);
}
