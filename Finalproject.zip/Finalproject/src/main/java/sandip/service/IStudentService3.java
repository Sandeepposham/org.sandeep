package sandip.service;

import java.util.List;
import java.util.Optional;

import sandip.model.Ambulance;

public interface IStudentService3 {

	Integer saveStudent(Ambulance s);
	void updateStudent(Ambulance s);
	
	void deleteStudent(Integer id);

	Optional<Ambulance> getOneStudent(Integer id);
	List<Ambulance> getAllStudents();

	boolean isStudentExist(Integer id);
}
