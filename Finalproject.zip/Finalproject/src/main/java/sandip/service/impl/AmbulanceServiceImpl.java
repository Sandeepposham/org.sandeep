package sandip.service.impl;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import sandip.model.Ambulance;
import sandip.repo.AmbulanceRepository2;
import sandip.service.IStudentService3;

@Service
public class AmbulanceServiceImpl implements IStudentService3 {

	@Autowired
	private AmbulanceRepository2 repo;
	
	@Override
	public Integer saveStudent(Ambulance s) {
		s = repo.save(s);
		return s.getId();
	}

	@Override
	public void updateStudent(Ambulance s) {
		repo.save(s);
	}

	@Override
	public void deleteStudent(Integer id) {
		repo.deleteById(id);
	}

	@Override
	public Optional<Ambulance> getOneStudent(Integer id) {
		return repo.findById(id);
	}

	@Override
	public List<Ambulance> getAllStudents() {
		return repo.findAll();
	}

	@Override
	public boolean isStudentExist(Integer id) {
		return repo.existsById(id);
	}

}
