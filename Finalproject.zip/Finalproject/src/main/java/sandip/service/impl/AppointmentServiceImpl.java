package sandip.service.impl;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import sandip.model.Appointment;
import sandip.repo.AppointmentRepository;
import sandip.service.IStudentService2;

@Service
public class AppointmentServiceImpl implements IStudentService2 {

	@Autowired
	private AppointmentRepository repo;
	
	@Override
	public Integer saveStudent(Appointment s) {
		s = repo.save(s);
		return s.getId();
	}

	@Override
	public void updateStudent(Appointment s) {
		repo.save(s);
	}

	@Override
	public void deleteStudent(Integer id) {
		repo.deleteById(id);
	}

	@Override
	public Optional<Appointment> getOneStudent(Integer id) {
		return repo.findById(id);
	}

	@Override
	public List<Appointment> getAllStudents() {
		return repo.findAll();
	}

	@Override
	public boolean isStudentExist(Integer id) {
		return repo.existsById(id);
	}

}
