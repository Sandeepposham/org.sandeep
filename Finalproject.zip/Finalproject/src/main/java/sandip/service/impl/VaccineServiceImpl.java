package sandip.service.impl;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import sandip.model.Vaccine;
import sandip.repo.VaccineRepository;
import sandip.service.IStudentService5;

@Service
public class VaccineServiceImpl implements IStudentService5 {

	@Autowired
	private VaccineRepository repo;
	
	@Override
	public Integer saveStudent(Vaccine s) {
		s = repo.save(s);
		return s.getId();
	}

	@Override
	public void updateStudent(Vaccine s) {
		repo.save(s);
	}

	@Override
	public void deleteStudent(Integer id) {
		repo.deleteById(id);
	}

	@Override
	public Optional<Vaccine> getOneStudent(Integer id) {
		return repo.findById(id);
	}

	@Override
	public List<Vaccine> getAllStudents() {
		return repo.findAll();
	}

	@Override
	public boolean isStudentExist(Integer id) {
		return repo.existsById(id);
	}

}
