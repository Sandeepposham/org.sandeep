package sandip.service;

import java.util.List;
import java.util.Optional;

import sandip.model.Bookbed;

public interface IStudentService4 {

	Integer saveStudent(Bookbed s);
	void updateStudent(Bookbed s);
	
	void deleteStudent(Integer id);

	Optional<Bookbed> getOneStudent(Integer id);
	List<Bookbed> getAllStudents();

	boolean isStudentExist(Integer id);
}
