package sandip.service;

import java.util.List;
import java.util.Optional;

import sandip.model.Appointment;

public interface IStudentService2 {

	Integer saveStudent(Appointment s);
	void updateStudent(Appointment s);
	
	void deleteStudent(Integer id);

	Optional<Appointment> getOneStudent(Integer id);
	List<Appointment> getAllStudents();

	boolean isStudentExist(Integer id);
}
