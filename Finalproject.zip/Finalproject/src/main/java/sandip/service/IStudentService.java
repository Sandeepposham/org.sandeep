package sandip.service;

import java.util.List;
import java.util.Optional;

import sandip.model.Feedback;

public interface IStudentService {

	Integer saveStudent(Feedback s);
	void updateStudent(Feedback s);
	
	void deleteStudent(Integer id);

	Optional<Feedback> getOneStudent(Integer id);
	List<Feedback> getAllStudents();

	boolean isStudentExist(Integer id);
}
