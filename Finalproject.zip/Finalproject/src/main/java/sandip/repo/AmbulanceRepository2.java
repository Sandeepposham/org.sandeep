package sandip.repo;

import org.springframework.data.jpa.repository.JpaRepository;

import sandip.model.Ambulance;

public interface AmbulanceRepository2 extends JpaRepository<Ambulance, Integer>
{

}
