package sandip.repo;

import org.springframework.data.jpa.repository.JpaRepository;

import sandip.model.Bookbed;

public interface BookbedRepository extends JpaRepository<Bookbed, Integer>
{

}
