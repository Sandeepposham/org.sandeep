package sandip.repo;

import org.springframework.data.jpa.repository.JpaRepository;

import sandip.model.Vaccine;

public interface VaccineRepository extends JpaRepository<Vaccine, Integer>
{

}
